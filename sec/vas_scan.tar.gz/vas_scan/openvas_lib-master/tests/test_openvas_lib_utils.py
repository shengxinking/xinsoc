import unittest


class TestSetInterval(unittest.TestCase):
    pass
    # def test_set_interval(self):
    #     # self.assertEqual(expected, set_interval(interval, times))
    #     assert False # TODO: implement your test here


class TestGenerateRandomString(unittest.TestCase):
    pass
    # def test_generate_random_string(self):
    #     # self.assertEqual(expected, generate_random_string(length))
    #     assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
