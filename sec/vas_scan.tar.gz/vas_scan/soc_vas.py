#!/usr/bin/env python
from openvas_lib import VulnscanManager, VulnscanException

try:
	scanner = VulnscanManager("127.0.0.1", "admin", "123456", 1111, 10)
except VulnscanException, e:
	print "Error:"
	print e
	scan_id, target_id = scanner.launch_scan(target = "127.0.0.1", # Target to scan
                                             profile = "Full and fast")
